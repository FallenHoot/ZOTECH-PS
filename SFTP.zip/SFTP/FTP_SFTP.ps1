﻿#If you are using SFTP make sure to look at the Function TroubleShoot_LoadException. This will fix the issue. It registers the .dll

Function Menu{
#----------------------------------------------------------
#DYNAMIC VARIABLES
#----------------------------------------------------------
cls
$Title="SFTP & FTP Menu"
Write-Host "================ $Title ================"  -Fore Magenta

Write-Host "`n Choose SFTP Location:" -Fore Cyan
[int]$global:Menu = 0
while ( $global:Menu -lt 1 -or $global:Menu -gt 4 ){
Write-host "1. Option 1" -Fore Cyan
Write-host "2. Option 2" -Fore Cyan
Write-host "3. Option 3" -Fore Cyan
Write-host "4. Option 4" -Fore Cyan
[Int]$global:Menu = read-host "Choose an option 1 to 4" }
Switch( $global:Menu ){
  1{$global:FTPdirectory= "Test1/"}
  2{$global:FTPdirectory= "Test2/"}
  3{$global:FTPdirectory= "Test3/"}
  4{$global:FTPdirectory= "Test4/"}
}
$Global:source = "ftp://USERNAME:PASSWORD@EXTERNALIP/$global:FTPdirectory"
$Global:SFTPsource = "IPADRESS"
$Global:target = "C:\SFTP\$global:FTPdirectory"
$Global:dllpath="C:\Zach's Documentation\SFTP\Rebex.Sftp.dll"
$Global:SFTPUser="P_668500_RS"
$Global:SFTPpass="ChuwexaQu6T2hus"
}

Function Get-FTP{
function Get-FTPDir{
    $request = [Net.WebRequest]::Create($Global:source)
    $request.Method = [System.Net.WebRequestMethods+FTP]::ListDirectory
    $response = $request.GetResponse()
    $reader = New-Object IO.StreamReader $response.GetResponseStream() 
	$reader.ReadToEnd()
	$reader.Close()
	$response.Close()
}

if(!(Test-Path -Path $Global:target )){
    New-Item -ItemType directory -Path $Global:target
}

$WebClient = New-Object System.Net.WebClient
$files=Get-FTPDir | Out-String
$files = $files.replace("`r",",")
$files = $files.replace("`n","")
$files = $files.trimend(",")
$array = $files -split ","

Foreach ($file in ($array | where {$_ -Like "*"})){
	$source=$Global:source+$file 
    $target=$Global:target+$file
	$WebClient.DownloadFile($source, $target)
    Write-Host "Downloaded: $file"
}
}
Function TroubleShoot_LoadException{
$BinPath = "C:\Zach's Documentation\SFTP"
  try
  {
    $Error.Clear()
    Push-Location $BinPath
    Get-ChildItem "*.dll" | Foreach {
    Write-Host $_.Name;
        $assembly = Add-Type -Path $_.FullName;    
    }
  }
  catch 
  {
    Write-Host -foreground yellow "LoadException";
    $Error | format-list -force
    Write-Host -foreground red $Error[0].Exception.LoaderExceptions;
  }
 
Write-Host "Complete."
Pop-Location
}
Function Get-SFTP{

Function Get-SFTPFiles {  
    Process
    {
        $sftp = New-Object Rebex.Net.Sftp
        $sftp.Connect($Global:SFTPsource)
        $sftp.Login($user,$pass)  
        $items = $sftp.GetList() | Where {$_ -Like "*"}
        $sftp.GetCurrentDirectory("Data_Files/")
        foreach ($item in $items)
        {
            $grab = $item.Name
            $save = $dest + $grab
            $sftp.GetFile($grab, $save)
        }
        $sftp.Disconnect()
        $sftp.Dispose()
    } }
}
Menu
#Get-FTP
#Get-SFTPFiles